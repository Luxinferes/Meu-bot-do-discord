const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");
const parceiro = require("./parceiro");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("criar-parceiros")
        .setDescription("Adiciona ou remove parceiros")
        .addStringOption(option =>
            option
                .setName("acao")
                .setDescription("Escolha entre adicionar ou remover.")
                .setRequired(true)
                .addChoices(
                    { name: "Adicionar", value: "adicionar" },
                    { name: "Remover", value: "remover" }
                )
        )
        .addStringOption(option =>
            option
                .setName("nome")
                .setDescription("Adicione o nome do parceiro")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("tipo")
                .setDescription("Escreva o tipo de parceiro Ex: Guardiao")
                .setRequired(true) 
        )
        .addStringOption(option =>
            option
                .setName("descricao")
                .setDescription("Descreva o poder do seu parceiro")
                .setRequired(true)
        ),
    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            // Verifica se a ficha existe
            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Você ainda não tem uma ficha. Crie uma usando o comando **/criar-ficha**.",
                    ephemeral: true,
                });
            }

            // Garante que o campo 'poderes' exista
            if (!Array.isArray(jogadorFicha.parceiro)) {
                jogadorFicha.parceiro = [];
            }

            const acao = interaction.options.getString("acao");
            const nome = interaction.options.getString("nome");
            const tipo = interaction.options.getString("tipo");
            const descricao = interaction.options.getString("descricao");

            if (acao === "adicionar") {
               
                if (jogadorFicha.parceiro.some(parceiro => parceiro.nome === nome)) {
                    return await interaction.reply({
                        content: `O parceiro "${nome}" já está na sua lista de parceiros.`,
                        ephemeral: true,
                    });
                }


                jogadorFicha.parceiro.push({
                    nome,
                    tipo: tipo || "N/A",
                    descricao: descricao || "N/A",
                });

                await interaction.reply({
                    content: `O parceiro "${nome}" foi adicionado com sucesso!`,
                    ephemeral: true,
                });
            } else if (acao === "remover") {
                // Encontra o índice do poder
                const index = jogadorFicha.parceiro.findIndex(parceiro => parceiro.nome === nome);

                if (index === -1) {
                    return await interaction.reply({
                        content: `O parceiro "${nome}" não foi encontrado.`,
                        ephemeral: true,
                    });
                }

                // Remove o poder pelo índice
                jogadorFicha.parceiro.splice(index, 1);

                await interaction.reply({
                    content: `O parceiro "${nome}" foi abandonado`,
                    ephemeral: true,
                });
            }

            // Salva a ficha atualizada
            fs.writeFileSync(fichasPath, JSON.stringify(fichas, null, 2));
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao editar sua lista de parceiros. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
