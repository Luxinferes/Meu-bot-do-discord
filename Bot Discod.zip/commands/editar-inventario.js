const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("editar-inventario")
        .setDescription("Adiciona, remove ou edita itens do seu inventário.")
        .addStringOption(option =>
            option
                .setName("acao")
                .setDescription("Escolha entre adicionar, remover ou editar um item.")
                .setRequired(true)
                .addChoices(
                    { name: "Adicionar", value: "adicionar" },
                    { name: "Remover", value: "remover" },
                    { name: "Editar", value: "editar" }
                )
        )
        .addStringOption(option =>
            option
                .setName("tipo")
                .setDescription("Escolha o tipo de equipamento.")
                .setRequired(true)
                .addChoices(
                    { name: "Arma", value: "arma" },
                    { name: "Armadura", value: "armadura" },
                    { name: "Item Geral", value: "item_geral" }
                )
        )
        .addStringOption(option =>
            option
                .setName("nome")
                .setDescription("O nome do item que deseja adicionar, remover ou editar.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("preco")
                .setDescription("Adicione ou edite o preço do item.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("peso")
                .setDescription("Adicione ou edite o peso do item.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("descricao")
                .setDescription("Adicione ou edite uma descrição para o item.")
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("dano")
                .setDescription("Adicione ou edite o dano da sua arma.")
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("margem_ameaça")
                .setDescription("Adicione ou edite o valor que você crita.")
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("critico")
                .setDescription("Adicione ou edite o valor que você multiplica os dados.")
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("defesa")
                .setDescription("Adicione ou edite a quantidade de defesa da sua armadura.")
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("penalidade_armadura")
                .setDescription("Adicione ou edite o valor da sua penalidade de armadura.")
                .setRequired(false)
        )
        .addStringOption(option =>
            option
                .setName("quantidade")
                .setDescription("Adicione ou edite a quantidade de itens.")
                .setRequired(false)
        ),

    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Você ainda não possui uma ficha. Use o comando /criar-ficha para criar uma.",
                    ephemeral: true,
                });
            }

            if (!jogadorFicha.inventario) {
                jogadorFicha.inventario = [];
            }

            const acao = interaction.options.getString("acao");
            const tipo = interaction.options.getString("tipo");
            const nome = interaction.options.getString("nome");
            const preco = interaction.options.getString("preco");
            const peso = interaction.options.getString("peso");
            const descricao = interaction.options.getString("descricao");
            const quantidade = interaction.options.getString("quantidade");

            // Para armas
            const dano = interaction.options.getString("dano");
            const margemAmeaça = interaction.options.getString("margem_ameaça");
            const critico = interaction.options.getString("critico");

            // Para armaduras
            const defesa = interaction.options.getString("defesa");
            const penalidadeArmadura = interaction.options.getString("penalidade_armadura");

            if (!nome || nome.trim() === "") {
                return await interaction.reply({
                    content: "Você precisa fornecer um nome válido para o item.",
                    ephemeral: true,
                });
            }

            if (acao === "adicionar") {
                let novoItem;

                if (tipo === "arma") {
                    if (!dano || !margemAmeaça || !critico) {
                        return await interaction.reply({
                            content: "Você precisa preencher os campos de dano, margem de ameaça e crítico.",
                            ephemeral: true,
                        });
                    }
                    novoItem = {
                        tipo: "arma",
                        nome,
                        descricao,
                        preco,
                        peso,
                        dano,
                        margemAmeaça,
                        critico,
                    };
                } else if (tipo === "armadura") {
                    if (!defesa || !penalidadeArmadura) {
                        return await interaction.reply({
                            content: "Você precisa preencher os campos de defesa e penalidade de armadura.",
                            ephemeral: true,
                        });
                    }
                    novoItem = {
                        tipo: "armadura",
                        nome,
                        descricao,
                        preco,
                        peso,
                        defesa,
                        penalidadeArmadura,
                    };
                } else if (tipo === "item_geral") {
                    novoItem = {
                        tipo: "item_geral",
                        nome,
                        descricao,
                        preco,
                        peso,
                        quantidade,
                    };
                }
                jogadorFicha.inventario.push(novoItem);
                await interaction.reply({
                    content: `O item "${nome}" foi adicionado ao seu inventário.`,
                    ephemeral: true,
                });
            } else if (acao === "remover") {
                const index = jogadorFicha.inventario.findIndex(i => i.nome === nome);
                if (index === -1) {
                    return await interaction.reply({
                        content: `O item "${nome}" não foi encontrado no seu inventário.`,
                        ephemeral: true,
                    });
                }
                jogadorFicha.inventario.splice(index, 1);
                await interaction.reply({
                    content: `O item "${nome}" foi removido do seu inventário.`,
                    ephemeral: true,
                });
            } else if (acao === "editar") {
                const item = jogadorFicha.inventario.find(i => i.nome === nome);
                if (!item) {
                    return await interaction.reply({
                        content: `O item "${nome}" não foi encontrado no seu inventário.`,
                        ephemeral: true,
                    });
                }

                // Atualiza os campos fornecidos
                if (preco) item.preco = preco;
                if (peso) item.peso = peso;
                if (descricao) item.descricao = descricao;
                if (quantidade) item.quantidade = quantidade;

                if (tipo === "arma") {
                    if (dano) item.dano = dano;
                    if (margemAmeaça) item.margemAmeaça = margemAmeaça;
                    if (critico) item.critico = critico;
                } else if (tipo === "armadura") {
                    if (defesa) item.defesa = defesa;
                    if (penalidadeArmadura) item.penalidadeArmadura = penalidadeArmadura;
                }

                await interaction.reply({
                    content: `O item "${nome}" foi atualizado no seu inventário.`,
                    ephemeral: true,
                });
            }

            fs.writeFileSync(fichasPath, JSON.stringify(fichas, null, 2));
        } catch (error) {
            console.error("Erro no comando editar-inventario:", error);
            await interaction.reply({
                content: "Ocorreu um erro ao editar seu inventário. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
