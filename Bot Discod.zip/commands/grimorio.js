const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("grimorio")
        .setDescription("Veja todas as suas magias organizadas por círculo."),

    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            // Verifica se a ficha existe
            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Crie uma ficha primeiro.",
                    ephemeral: true,
                });
            }

            // Verifica se há magias registradas
            if (!jogadorFicha.magias || jogadorFicha.magias.length === 0) {
                return await interaction.reply({
                    content: "Você ainda não adicionou nenhuma magia.",
                    ephemeral: true,
                });
            }

            // Organiza as magias por círculo e ordem alfabética
            const magiasPorCirculo = { 1: [], 2: [], 3: [], 4: [], 5: [] };
            jogadorFicha.magias.forEach(magia => {
                if (magiasPorCirculo[magia.circulo]) {
                    magiasPorCirculo[magia.circulo].push(magia.nome);
                }
            });

            // Ordena as magias dentro de cada círculo
            for (const circulo in magiasPorCirculo) {
                magiasPorCirculo[circulo].sort();
            }

            // Monta a resposta
            let resposta = "**Suas Magias**\n\n";
            for (let circulo = 1; circulo <= 5; circulo++) {
                resposta += `**Círculo ${circulo}**:\n`;
                if (magiasPorCirculo[circulo].length > 0) {
                    resposta += magiasPorCirculo[circulo]
                        .map(nome => `- ${nome}`)
                        .join("\n");
                } else {
                    resposta += "- Nenhuma magia registrada.";
                }
                resposta += "\n\n";
            }

            await interaction.reply({
                content: resposta,
                ephemeral: false,
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao visualizar suas magias. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
