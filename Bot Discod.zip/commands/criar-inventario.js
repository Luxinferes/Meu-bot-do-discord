const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("criar-inventario")
        .setDescription("Cria uma invetario para sua ficha"),
    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            // Verifica se o arquivo existe
            if (!fs.existsSync(fichasPath)) {
                fs.writeFileSync(fichasPath, JSON.stringify({}, null, 2));
            }

            // Carrega as fichas
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));

            // Verifica se o jogador tem uma ficha
            if (!fichas[interaction.user.id]) {
                return await interaction.reply({
                    content: "Crie uma ficha primeiro.",
                    ephemeral: true,
                });
            }

            // Verifica se o inventário já existe
            if (fichas[interaction.user.id].inventario) {
                return await interaction.reply({
                    content: "Voce ja tem um inventario cabeça de pica",
                    ephemeral: true,
                });
            }

            // Cria o inventário vazio
            fichas[interaction.user.id].inventario = [];

            // Salva no arquivo
            fs.writeFileSync(fichasPath, JSON.stringify(fichas, null, 2));

            await interaction.reply({
                content: "Inventário criado com sucesso",
                ephemeral: true,
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao criar seu inventário",
                ephemeral: true,
            });
        }
    },
};
