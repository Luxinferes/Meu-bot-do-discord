const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("importar-ficha-texto")
        .setDescription("Importa uma ficha pronta colando o texto.")
        .addStringOption(option =>
            option
                .setName("ficha")
                .setDescription("Cole o texto da ficha pronta aqui.")
                .setRequired(true)
        ),
    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            const fichaTexto = interaction.options.getString("ficha");

            // Converte o texto da ficha para um objeto JSON
            const ficha = {};
            const linhas = fichaTexto.split("\n");

            let secaoAtual = null;

            linhas.forEach(linha => {
                linha = linha.trim();
                if (!linha) return;

                // Detecta se é uma seção (Atributos, Personagem, Perícias)
                if (/^Atributos$/i.test(linha)) {
                    secaoAtual = "Atributos";
                    ficha[secaoAtual] = {};
                } else if (/^Personagem$/i.test(linha)) {
                    secaoAtual = "Personagem";
                    ficha[secaoAtual] = {};
                } else if (/^Perícias$/i.test(linha)) {
                    secaoAtual = "Perícias";
                    ficha[secaoAtual] = {};
                } else if (!secaoAtual) {
                    // É um campo básico fora de seção
                    const [chave, ...valor] = linha.split(":");
                    ficha[chave.trim()] = valor.join(":").trim();
                } else {
                    // É um campo dentro de uma seção
                    const [chave, ...valor] = linha.split(":");
                    ficha[secaoAtual][chave.trim()] = valor.length > 0 ? valor.join(":").trim() : "";
                }
            });

            // Validação básica
            if (!ficha.Nome || !ficha.Atributos || !ficha.Personagem) {
                return interaction.reply({
                    content: "A ficha fornecida não está completa ou bem formatada, vai concertar cabeça de pica",
                    ephemeral: true,
                });
            }

            // Carrega ou cria o arquivo de fichas
            const fichas = fs.existsSync(fichasPath)
                ? JSON.parse(fs.readFileSync(fichasPath, "utf-8"))
                : {};

            // Usa o ID do jogador como chave
            fichas[interaction.user.id] = ficha;

            // Salva no arquivo
            fs.writeFileSync(fichasPath, JSON.stringify(fichas, null, 2));

            await interaction.reply({
                content: "Sua ficha foi importada com sucesso!",
                ephemeral: true,
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao importar sua ficha. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
