const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("excluir-ficha")
        .setDescription("Exclui sua ficha de RPG do sistema"),
    async execute(interaction) {
        const fichasPath = "./fichas.json"; 

        try {
            // Verifica se o arquivo JSON existe
            if (!fs.existsSync(fichasPath)) {
                return await interaction.reply({
                    content: "Nenhuma ficha foi encontrada no sistema.",
                    ephemeral: true,
                });
            }

            // Carrega o arquivo de fichas
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));

            // Verifica se o usuário possui uma ficha cadastrada
            if (!fichas[interaction.user.id]) {
                return await interaction.reply({
                    content: "Você não possui uma ficha cadastrada para excluir.",
                    ephemeral: true,
                });
            }

            // Remove a ficha do usuário
            delete fichas[interaction.user.id];

            // Salva as alterações no arquivo JSON
            fs.writeFileSync(fichasPath, JSON.stringify(fichas, null, 2));

            // Confirmação para o usuário
            await interaction.reply({
                content: "Sua ficha foi excluída com sucesso!",
                ephemeral: true,
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao tentar excluir sua ficha. Por favor, tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
