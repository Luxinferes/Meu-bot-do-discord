const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("poderes")
        .setDescription("Mostra a lista de poderes do seu personagem."),
    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            // Lê o arquivo de fichas
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            // Verifica se a ficha existe
            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Voce ainda nao tem uma ficha. Crie uma usando o comando **/criar-ficha**.",
                    ephemeral: true,
                });
            }

            // Verifica se há poderes na ficha
            if (!Array.isArray(jogadorFicha.poderes) || jogadorFicha.poderes.length === 0) {
                return await interaction.reply({
                    content: "Sua lista de poderes esta vazia. Adicione poderes com o comando **/editar-poderes**.",
                    ephemeral: true,
                });
            }

            // Formata a lista de poderes
            let poderesFormatados = jogadorFicha.poderes.map((poder, index) => 
                `**Nome:** ${poder.nome}\n` +
                `**Tipo:** ${poder.tipo}\n` +
                `**Descrição:** ${poder.descricao}`
            ).join("\n\n");

            // Envia a resposta com a lista de poderes
            await interaction.reply({
                content: `**Poderes do seu personagem:**\n\n${poderesFormatados}`,
                ephemeral: false,
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao carregar sua lista de poderes. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
