const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("editar-inventario")
        .setDescription("Adiciona ou remove itens do seu inventário.")
        .addStringOption(option =>
            option
                .setName("acao")
                .setDescription("Escolha entre adicionar ou remover um item.")
                .setRequired(true)
                .addChoices(
                    { name: "Adicionar", value: "adicionar" },
                    { name: "Remover", value: "remover" }
                )
        )
        .addStringOption(option =>
            option
                .setName("item")
                .setDescription("O item que deseja adicionar ou remover.")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("preco")
                .setDescription("Adicione o preço do seu item")
                .setRequired(false) // Opcional
        )
        .addStringOption(option =>
            option
                .setName("peso")
                .setDescription("Adicione o peso do seu item")
                .setRequired(false) // Opcional
        )
        .addStringOption(option =>
            option
                .setName("descricao")
                .setDescription("Adicione a descrição do seu item")
                .setRequired(false) // Opcional
        ),

    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            // Verifica se a ficha e o inventário existem
            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Crie uma ficha primeiro.",
                    ephemeral: true,
                });
            }
            if (!jogadorFicha.inventario) {
                jogadorFicha.inventario = []; // Inicializa o inventário caso não exista
            }

            const acao = interaction.options.getString("acao");
            const item = interaction.options.getString("item");
            const preco = interaction.options.getString("preco") || "N/A";
            const peso = interaction.options.getString("peso") || "N/A";
            const descricao = interaction.options.getString("descricao") || "Sem descrição";

            // Adiciona ou remove o item
            if (acao === "adicionar") {
                const novoItem = { item, preco, peso, descricao };
                jogadorFicha.inventario.push(novoItem); // Adiciona o item como objeto
                await interaction.reply({
                    content: `O item "${item}" foi adicionado ao seu inventário.`,
                    ephemeral: true,
                });
            } else if (acao === "remover") {
                const index = jogadorFicha.inventario.findIndex(i => i.item === item);
                if (index === -1) {
                    return await interaction.reply({
                        content: `O item "${item}" não foi encontrado no seu inventário.`,
                        ephemeral: true,
                    });
                }
                jogadorFicha.inventario.splice(index, 1); // Remove o item pelo índice
                await interaction.reply({
                    content: `O item "${item}" foi removido do seu inventário.`,
                    ephemeral: true,
                });
            }

            // Salva no arquivo
            fs.writeFileSync(fichasPath, JSON.stringify(fichas, null, 2));
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao editar seu inventário. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
