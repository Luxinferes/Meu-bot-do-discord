const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("ver-inventario")
        .setDescription("Mostra os itens do seu inventário."),
    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            // Verifica se a ficha e o inventário existem
            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Voce precisa criar uma ficha antes de visualizar o inventário.",
                    ephemeral: true,
                });
            }
            if (!jogadorFicha.inventario) {
                return await interaction.reply({
                    content: "Voce ainda não possui um inventário. Use /criar-inventario para criar um.",
                    ephemeral: true,
                });
            }

            // Formata a lista de itens
            const inventario = jogadorFicha.inventario;
            const lista = inventario.length
                ? inventario.map((item, index) => `${index + 1}. ${item}`).join("\n")
                : "Seu inventário está vazio.";

            await interaction.reply({
                content: `**Seu Inventário:**\n${lista}`,
                ephemeral: true,
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao exibir seu inventário. Tente novamente mais tarde.",
                ephemeral: false,
            });
        }
    },
};
