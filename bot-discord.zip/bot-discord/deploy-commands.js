const { REST, Routes } = require('discord.js');
const dotenv = require('dotenv');
dotenv.config();

const { CLIENT_ID, TOKEN } = process.env;

// Importa os comandos
const fs = require('node:fs');
const path = require('node:path');

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    if ('data' in command && 'execute' in command) {
        commands.push(command.data.toJSON());
    } else {
        console.log(`Esse comando em ${filePath} esta com "data" ou com "execute" Ausentes`);
    }
}

// Cria uma instância da REST API
const rest = new REST({ version: '10' }).setToken(TOKEN);

// Registra comandos globais
(async () => {
    try {
        console.log(`Resentando ${commands.length} comandos...`);

        const data = await rest.put(
            Routes.applicationCommands(CLIENT_ID),
            { body: commands },
        );

        console.log('Comandos registrados');
    } catch (error) {
        console.error(error);
    }
})();
