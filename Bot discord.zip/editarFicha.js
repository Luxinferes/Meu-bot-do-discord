const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("editar-ficha")
        .setDescription("Edita sua ficha de RPG")
        .addStringOption(option =>
            option
                .setName("campo")
                .setDescription("Campo que deseja editar (Ex: Nome, For, XP)")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("valor")
                .setDescription("Novo valor para o campo escolhido")
                .setRequired(true)
        ),
    async execute(interaction) {
        const filePath = "./fichas.json";
        const userId = interaction.user.id;

        // Verifica se o arquivo de fichas existe
        if (!fs.existsSync(filePath)) {
            return interaction.reply({
                content: "Nenhuma ficha foi encontrada. Use o comando **/criar-ficha** para criar sua ficha.",
                ephemeral: true,
            });
        }

        // Carregar fichas
        const fichas = JSON.parse(fs.readFileSync(filePath, "utf8"));

        // Verifica se o jogador tem uma ficha criada
        if (!fichas[userId]) {
            return interaction.reply({
                content: "Você ainda não possui uma ficha. Use o comando **/criar-ficha** para criar sua ficha.",
                ephemeral: true,
            });
        }

        // Obtém o campo e o valor fornecidos pelo usuário
        const campo = interaction.options.getString("campo");
        let valor = interaction.options.getString("valor");

        // Referência para a ficha do jogador
        const ficha = fichas[userId];

        // Atualiza o campo na ficha
        if (campo in ficha) {
            ficha[campo] = valor;
        } else if (campo in ficha.Atributos) {
            ficha.Atributos[campo] = parseInt(valor) || 0; // Garante que seja número
        } else if (campo in ficha.Personagem) {
            ficha.Personagem[campo] = parseInt(valor) || 0; // Garante que seja número
        } else if (campo in ficha["Perícias"]) {
            ficha["Perícias"][campo] = parseInt(valor) || 0; // Garante que seja número
        } else {
            return interaction.reply({
                content: `O campo **${campo}** não é válido. Verifique o nome do campo e tente novamente.`,
                ephemeral: true,
            });
        }

        // Salva a ficha atualizada no arquivo
        fs.writeFileSync(filePath, JSON.stringify(fichas, null, 4), "utf8");

        // Responde ao usuário
        return interaction.reply({
            content: `O campo **${campo}** foi atualizado com sucesso para **${valor}**!`,
            ephemeral: true,
        });
    },
};
