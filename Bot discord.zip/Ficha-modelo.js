const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("ficha-modelo")
        .setDescription("Mostra o modelo de ficha de RPG para o jogador"),
    async execute(interaction) {
        const fichaModelo = `
**Nome:** 
**Idade:** 
**Nível:** 
**Classe:** 
**Raça:** 
**Origem:** 
**Alinhamento:** 
**Deus:** 
**XP:** 

**Atributos**
**For:** 
**Des:** 
**Con:** 
**Int:** 
**Sab:** 
**Car:** 

**Personagem**
**Defesa:** 
**CD:** 
**Pm:** 
**Pm Max:** 
**Hp:** 
**Hp Max:** 
**Iniciativa:** 
**Deslocamento:** 
**Metade do Nível:** 

**Perícias**
**Acrobacia (Des):** 
**Adestramento (Car):** 
**Atletismo (For):** 
**Atuação (Car):** 
**Cavalgar (Des):** 
**Conhecimento (Int):** 
**Cura (Sab):** 
**Diplomacia (Car):** 
**Enganação (Car):** 
**Fortitude (Con):** 
**Furtividade (Des):** 
**Guerra (Int):** 
**Iniciativa (Des):** 
**Intimidação (Car):** 
**Intuição (Sab):** 
**Investigação (Int):** 
**Jogatina (Car):** 
**Ladinagem (Des):** 
**Luta (For):** 
**Misticismo (Int):** 
**Nobreza (Int):** 
**Ofício (Alquimia) (Int):** 
**Percepção (Sab):** 
**Pilotagem (Des):** 
**Pontaria (Des):** 
**Reflexos (Des):** 
**Religião (Sab):** 
**Sobrevivência (Sab):** 
**Vontade (Sab):**
        `;

        await interaction.reply({
            content: fichaModelo,
            ephemeral: false,
        });
    },
};
