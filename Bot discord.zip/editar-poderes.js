const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("editar-poderes")
        .setDescription("Adiciona, remove ou edita a descrição de poderes na sua lista")
        .addStringOption(option =>
            option
                .setName("acao")
                .setDescription("Escolha entre adicionar, remover ou editar um poder")
                .setRequired(true)
                .addChoices(
                    { name: "Adicionar", value: "adicionar" },
                    { name: "Remover", value: "remover" },
                    { name: "Editar", value: "editar" }
                )
        )
        .addStringOption(option =>
            option
                .setName("nome")
                .setDescription("O nome do poder")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("tipo")
                .setDescription("O tipo do poder EX: combate, destino, concedido, origem")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("descricao")
                .setDescription("a descriçao do seu poder, nao pode passar de 200 caracteres")
                .setRequired(false)
        ),
    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            // Verifica se a ficha existe
            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Você ainda não tem uma ficha. Crie uma usando o comando **/criar-ficha**.",
                    ephemeral: true,
                });
            }

            // Garante que o campo 'poderes' exista
            if (!Array.isArray(jogadorFicha.poderes)) {
                jogadorFicha.poderes = [];
            }

            const acao = interaction.options.getString("acao");
            const nome = interaction.options.getString("nome");
            const tipo = interaction.options.getString("tipo");
            const descricao = interaction.options.getString("descricao");

            if (acao === "adicionar") {
                if (jogadorFicha.poderes.some(poder => poder.nome === nome)) {
                    return await interaction.reply({
                        content: `O poder "${nome}" já está na sua lista de poderes.`,
                        ephemeral: true,
                    });
                }

                if (!tipo) {
                    return await interaction.reply({
                        content: "Você precisa informar o tipo do poder para adicioná-lo.",
                        ephemeral: true,
                    });
                }

                jogadorFicha.poderes.push({
                    nome,
                    tipo,
                    descricao: descricao || "Descrição não especificada",
                });

                await interaction.reply({
                    content: `O poder "${nome}" foi adicionado com sucesso!`,
                    ephemeral: true,
                });
            } else if (acao === "remover") {
                const index = jogadorFicha.poderes.findIndex(poder => poder.nome === nome);

                if (index === -1) {
                    return await interaction.reply({
                        content: `O poder "${nome}" não foi encontrado.`,
                        ephemeral: true,
                    });
                }

                jogadorFicha.poderes.splice(index, 1);

                await interaction.reply({
                    content: `O poder "${nome}" foi removido com sucesso!`,
                    ephemeral: true,
                });
            } else if (acao === "editar") {
                const poder = jogadorFicha.poderes.find(poder => poder.nome === nome);

                if (!poder) {
                    return await interaction.reply({
                        content: `O poder "${nome}" não foi encontrado na sua lista de poderes.`,
                        ephemeral: true,
                    });
                }

                if (!descricao) {
                    return await interaction.reply({
                        content: "Você precisa fornecer uma nova descrição para editar o poder.",
                        ephemeral: true,
                    });
                }

                // Atualiza apenas a descrição
                poder.descricao = descricao;

                await interaction.reply({
                    content: `A descrição do poder "${nome}" foi atualizada com sucesso!`,
                    ephemeral: true,
                });
            }

            // Salva a ficha atualizada
            fs.writeFileSync(fichasPath, JSON.stringify(fichas, null, 2));
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao editar sua lista de poderes. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
