const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("criar-magia")
        .setDescription("Adicione uma magia à sua lista.")
        .addStringOption(option =>
            option
                .setName("nome")
                .setDescription("O nome da magia.")
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option
                .setName("circulo")
                .setDescription("O círculo da magia (1 a 5).")
                .setRequired(true)
                .addChoices(
                    { name: "1", value: 1 },
                    { name: "2", value: 2 },
                    { name: "3", value: 3 },
                    { name: "4", value: 4 },
                    { name: "5", value: 5 }
                )
        )
        .addStringOption(option =>
            option
                .setName("descricao")
                .setDescription("A descrição da magia.")
                .setRequired(false)
        ),

    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            // Verifica se a ficha existe
            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Crie uma ficha primeiro.",
                    ephemeral: true,
                });
            }

            // Inicializa o registro de magias se necessário
            if (!jogadorFicha.magias) {
                jogadorFicha.magias = [];
            }

            const nome = interaction.options.getString("nome");
            const circulo = interaction.options.getInteger("circulo");
            const descricao = interaction.options.getString("descricao");

            // Adiciona a nova magia
            const novaMagia = { nome, circulo, descricao };
            jogadorFicha.magias.push(novaMagia);

            // Salva no arquivo
            fs.writeFileSync(fichasPath, JSON.stringify(fichas, null, 2));

            await interaction.reply({
                content: `A magia "${nome}" foi adicionada ao círculo ${circulo} dentro da suas magias conhecidas.`,
                ephemeral: true,
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: "Ocorreu um erro ao adicionar a magia. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
