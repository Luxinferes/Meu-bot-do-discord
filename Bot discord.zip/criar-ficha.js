const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("criar-ficha")
        .setDescription("Cria uma ficha de RPG para o jogador")
        .addStringOption(option =>
            option
                .setName("nome")
                .setDescription("Nome do personagem")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("idade")
                .setDescription("Idade do personagem")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("classe")
                .setDescription("Classe do personagem")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("raca")
                .setDescription("Raça do personagem")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
            .setName("origem")
            .setDescription ("O que o seu personagem fazia antes de ser um aventureiro")
            .setRequired(true)
        )
        .addStringOption(option =>
            option
            .setName("alinhamento")
            .setDescription("Definiçao moral e etica do seu personagem")
            .setRequired(true)
        )
        .addStringOption(option =>
            option
            .setName("deus")
            .setDescription("O deus a qual seu personagem e devoto")
            .setRequired(true)
        ),
    async execute(interaction) {
        // Obter as informações fornecidas pelo jogador
        const nome = interaction.options.getString("nome");
        const idade = interaction.options.getString("idade");
        const classe = interaction.options.getString("classe");
        const raca = interaction.options.getString("raca");
        const origem = interaction.options.getString("origem");
        const alinhamento = interaction.options.getString("alinhamento");
        const deus = interaction.options.getString("deus");

        // Modelo completo da ficha
        const fichaModelo = {
            Nome: nome,
            Idade: idade,
            Nível: 1,
            Classe: classe,
            Raça: raca,
            Origem: origem,
            Alinhamento: alinhamento,
            Deus: deus,
            XP: 0,
            Atributos: {
                For: 0,
                Des: 0,
                Con: 0,
                Int: 0,
                Sab: 0,
                Car: 0,
            },
            Personagem: {
                Defesa: 0,
                CD: 0,
                Pm: 0,
                PmMax: 0,
                Hp: 0,
                HpMax: 0,
                Iniciativa: 0,
                Deslocamento: 0,
                MetadeDoNivel: 0,
            },
            Perícias: {
                "Acrobacia (Des)": 0,
                "Adestramento (Car)": 0,
                "Atletismo (For)": 0,
                "Atuação (Car)": 0,
                "Cavalgar (Des)": 0,
                "Conhecimento (Int)": 0,
                "Cura (Sab)": 0,
                "Diplomacia (Car)": 0,
                "Enganação (Car)": 0,
                "Fortitude (Con)": 0,
                "Furtividade (Des)": 0,
                "Guerra (Int)": 0,
                "Iniciativa (Des)": 0,
                "Intimidação (Car)": 0,
                "Intuição (Sab)": 0,
                "Investigação (Int)": 0,
                "Jogatina (Car)": 0,
                "Ladinagem (Des)": 0,
                "Luta (For)": 0,
                "Misticismo (Int)": 0,
                "Nobreza (Int)": 0,
                "Ofício (Alquimia) (Int)": 0,
                "Percepção (Sab)": 0,
                "Pilotagem (Des)": 0,
                "Pontaria (Des)": 0,
                "Reflexos (Des)": 0,
                "Religião (Sab)": 0,
                "Sobrevivência (Sab)": 0,
                "Vontade (Sab)": 0,
            },
        };

        // Ler ou criar o arquivo JSON das fichas
        const filePath = "./fichas.json";
        let fichas = {};
        if (fs.existsSync(filePath)) {
            fichas = JSON.parse(fs.readFileSync(filePath, "utf8"));
        }

        // Salvar a ficha do jogador
        fichas[interaction.user.id] = fichaModelo;

        // Escrever no arquivo JSON
        fs.writeFileSync(filePath, JSON.stringify(fichas, null, 2));

        await interaction.reply({
            content: `📝 **Ficha de Tormenta 20 criada com sucesso!**\n\n` +
                `Nome: ${nome}\n` +
                `Idade: ${idade}\n` +
                `Classe: ${classe}\n` +
                `Raça: ${raca}\n` +
                `Origem: ${origem}\n` +
                `Alinhamento: ${alinhamento}\n` +
                `Deus: ${deus}\n\n` +
                `Você pode editar outros campos com o comando **/editar-ficha**.`,
            ephemeral: true,
        });
    },
};
