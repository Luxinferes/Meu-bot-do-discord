const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("inventario")
        .setDescription("Exibe os itens do seu inventário."),
    async execute(interaction) {
        const fichasPath = "./fichas.json";

        try {
            // Carrega as fichas
            const fichas = JSON.parse(fs.readFileSync(fichasPath, "utf-8"));
            const jogadorFicha = fichas[interaction.user.id];

            // Verifica se a ficha e o inventário existem
            if (!jogadorFicha) {
                return await interaction.reply({
                    content: "Você ainda não possui uma ficha. Use o comando /criar-ficha para criar uma.",
                    ephemeral: true,
                });
            }

            if (!jogadorFicha.inventario || jogadorFicha.inventario.length === 0) {
                return await interaction.reply({
                    content: "Seu inventário está vazio.",
                    ephemeral: true,
                });
            }

            // Formata os itens do inventário
            const itensFormatados = jogadorFicha.inventario
                .map((item, index) => {
                    let detalhes = `
**Item ${index + 1}:**
- Nome: ${item.nome || "Nome não especificado"}
- Preço: ${item.preco || "Preço não especificado"}
- Peso: ${item.peso || "Peso não especificado"}
- Descrição: ${item.descricao || "Descrição não especificada"}
                    `;

                    if (item.tipo === "arma") {
                        detalhes += `
- Dano: ${item.dano || "Não especificado"}
- Margem de Ameaça: ${item.margemAmeaça || "Não especificado"}
- Crítico: ${item.critico || "Não especificado"}
                        `;
                    } else if (item.tipo === "armadura") {
                        detalhes += `
- Defesa: ${item.defesa || "Não especificado"}
- Penalidade de Armadura: ${item.penalidadeArmadura || "Não especificado"}
                        `;
                    } else if (item.tipo === "item_geral") {
                        detalhes += `
- Quantidade: ${item.quantidade || "Não especificado"}
                        `;
                    }

                    return detalhes;
                })
                .join("\n");

            // Responde com o inventário formatado
            await interaction.reply({
                content: `**Inventário de ${jogadorFicha.nome || "Jogador"}**\n\n${itensFormatados}`,
                ephemeral: false,
            });
        } catch (error) {
            console.error("Erro ao carregar o inventário:", error);
            await interaction.reply({
                content: "Ocorreu um erro ao exibir seu inventário. Tente novamente mais tarde.",
                ephemeral: true,
            });
        }
    },
};
