const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("ficha")
        .setDescription("Exibe sua ficha de RPG"),
    async execute(interaction) {
        const filePath = "./fichas.json";

        // Verifica se o arquivo de fichas existe
        if (!fs.existsSync(filePath)) {
            return interaction.reply({
                content: "Nenhuma ficha foi encontrada. Use o comando **/criar-ficha** para criar sua ficha.",
                ephemeral: true,
            });
        }

        // Carrega fichas
        const fichas = JSON.parse(fs.readFileSync(filePath, "utf8"));

        // Verifica se o jogador tem uma ficha criada
        const ficha = fichas[interaction.user.id];
        if (!ficha) {
            return interaction.reply({
                content: "Você ainda não possui uma ficha. Use o comando **/criar-ficha** para criar sua ficha.",
                ephemeral: true,
            });
        }

        // Formatar a ficha para exibição
        const atributos = ficha.Atributos || {};
        const personagem = ficha.Personagem || {};
        const pericias = ficha["Perícias"] || {};

        const fichaFormatada = `
📝 **Ficha de Tormenta 20**

**Nome:** ${ficha.Nome || "N/A"}
**Idade:** ${ficha.Idade || "N/A"}
**Nível:** ${ficha.Nível || 0}
**Classe:** ${ficha.Classe || "N/A"}
**Raça:** ${ficha.Raça || "N/A"}
**Origem:** ${ficha.Origem || "N/A"}
**Alinhamento:** ${ficha.Alinhamento || "N/A"}
**Deus:** ${ficha.Deus || "N/A"}
**XP:** ${ficha.XP || 0}

**Atributos**
- **For:** ${atributos.For || 0}
- **Des:** ${atributos.Des || 0}
- **Con:** ${atributos.Con || 0}
- **Int:** ${atributos.Int || 0}
- **Sab:** ${atributos.Sab || 0}
- **Car:** ${atributos.Car || 0}

**Personagem**
- **Defesa:** ${personagem.Defesa || 0}
- **CD:** ${personagem.CD || 0}
- **Pm:** ${personagem.Pm || 0}
- **Pm Max:** ${personagem.PmMax || 0}
- **Hp:** ${personagem.Hp || 0}
- **Hp Max:** ${personagem.HpMax || 0}
- **Iniciativa:** ${personagem.Iniciativa || 0}
- **Deslocamento:** ${personagem.Deslocamento || 0}
- **Metade do Nível:** ${personagem.MetadeDoNivel || 0}

**Perícias**
${Object.entries(pericias)
    .map(([pericia, valor]) => `- **${pericia}:** ${valor}`)
    .join("\n")}
        `;

        // Responde com a ficha formatada
        await interaction.reply({
            content: fichaFormatada,
            ephemeral: false,
        });
    },
};
